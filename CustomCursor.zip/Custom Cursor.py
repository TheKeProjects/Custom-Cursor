import os
import shutil
import tkinter as tk
from tkinter import messagebox, ttk
from PIL import Image, ImageTk, ImageDraw, ImageFont
import re
import winreg
import ctypes
import sys
import subprocess
import traceback
import urllib.request
import threading
import tempfile
import webbrowser

# ===== CONSTANTES Y CONFIGURACIÓN DE ACTUALIZACIONES =====
CONFIG_DIR = os.path.join(os.path.expanduser('~'), 'Documents', 'Custom-Cursor')
VERSION_FILE = os.path.join(CONFIG_DIR, 'custom_cursor_version.txt')
CHANGELOG_FILE = os.path.join(CONFIG_DIR, 'custom_cursor_changelog.txt')

# URLs para actualizaciones
GITHUB_REPO = "https://raw.githubusercontent.com/TheKeProjects/Custom-Cursor/main/version.txt"
GITHUB_CHANGELOG = "https://raw.githubusercontent.com/TheKeProjects/Custom-Cursor/main/changelog.txt"
UPDATE_URL = "https://github.com/TheKeProjects/Custom-Cursor/releases/latest"
INSTALLER_URL = "https://github.com/TheKeProjects/Custom-Cursor/releases/latest/download/Custom-Cursor_Setup.exe"

# =====================================================================
# ==================== FUNCIONES AUXILIARES ===========================
# =====================================================================

def get_base_dir():
    """Obtiene el directorio base del script o ejecutable."""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.abspath(__file__))

def get_icon_path():
    """Obtiene la ruta del archivo de icono"""
    base_dir = get_base_dir()
    icon_path = os.path.join(base_dir, "icon.ico")
    return icon_path if os.path.exists(icon_path) else None

# =====================================================================
# ==================== CÓDIGO PRINCIPAL DE CURSORES ===================
# =====================================================================

# Mapa de nombres del esquema al registro
REG_NAMES = {
    "pointer": "Arrow",
    "help": "Help",
    "work": "AppStarting",
    "busy": "Wait",
    "cross": "Crosshair",
    "text": "IBeam",
    "hand": "Hand",
    "unavailiable": "No",
    "vert": "SizeNS",
    "horz": "SizeWE",
    "dgn1": "SizeNWSE",
    "dgn2": "SizeNESW",
    "move": "SizeAll",
    "alternate": "UpArrow",
    "link": "Link",
    "pin": "LocationSelect",
    "person": "PersonSelect"
}

# Cache para placeholders
_PLACEHOLDER_CACHE = {
    'ani': None,
    'error': None,
    'no_preview': None
}

def get_cursor_dir():
    """Obtiene la ruta de la carpeta de cursores relativa al ejecutable/script"""
    try:
        base_dir = get_base_dir()
        # Carpeta de cursores en el mismo directorio
        cursor_dir = os.path.join(base_dir, "Cursores")
        
        # Si no existe, intentar crear
        if not os.path.exists(cursor_dir):
            os.makedirs(cursor_dir, exist_ok=True)
        
        return cursor_dir
    except Exception as e:
        messagebox.showerror("Error crítico", f"No se pudo crear la carpeta de cursores:\n{e}")
        sys.exit(1)

def parse_inf(path):
    """Analiza el archivo INF para extraer la configuración del cursor"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        matches = re.findall(r'(\w+)\s*=\s*"(.+?)"', content)
        cursor_map = dict(matches)

        scheme_match = re.search(r'SCHEME_NAME\s*=\s*"(.+?)"', content)
        scheme_name = scheme_match.group(1) if scheme_match else "Esquema Desconocido"

        return scheme_name, cursor_map
    except Exception as e:
        messagebox.showerror("Error", f"Error al analizar archivo INF:\n{e}")
        return "Error", {}

def set_cursor_registry(cursor_map, folder_path, scheme_name):
    """Configura el cursor en el registro de Windows creando un nuevo esquema"""
    try:
        # Sanitizar el nombre del esquema para usarlo como identificador
        safe_scheme_name = re.sub(r'[^a-zA-Z0-9 _-]', '', scheme_name)
        system_cursor_path = os.path.join(os.environ["WINDIR"], "Cursors", safe_scheme_name)

        # Crear carpeta si no existe
        os.makedirs(system_cursor_path, exist_ok=True)

        # Copiar los cursores al directorio del sistema
        for regname, filename in cursor_map.items():
            src = os.path.join(folder_path, filename)
            dst = os.path.join(system_cursor_path, filename)
            try:
                shutil.copy2(src, dst)
            except Exception as e:
                print(f"❌ Error copiando {filename}: {e}")
                # Intentar continuar con otros archivos

        # Crear el string del esquema
        scheme_string = []
        for regname in REG_NAMES:
            if regname in cursor_map:
                scheme_string.append(f"%SystemRoot%\\Cursors\\{safe_scheme_name}\\{cursor_map[regname]}")
            else:
                scheme_string.append("")

        full_scheme_str = ",".join(scheme_string)

        # Registrar el nuevo esquema
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, 
                                r"Control Panel\Cursors\Schemes", 
                                0, winreg.KEY_ALL_ACCESS) as key:
                winreg.SetValueEx(key, safe_scheme_name, 0, winreg.REG_SZ, full_scheme_str)
        except FileNotFoundError:
            # Crear la clave si no existe
            winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Cursors\Schemes")
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, 
                                r"Control Panel\Cursors\Schemes", 
                                0, winreg.KEY_ALL_ACCESS) as key:
                winreg.SetValueEx(key, safe_scheme_name, 0, winreg.REG_SZ, full_scheme_str)
        except Exception as e:
            print(f"Error al registrar el esquema: {e}")
            return False

        # Establecer el nuevo esquema como activo
        SPI_SETCURSORS = 0x0057
        SPIF_UPDATEINIFILE = 0x01
        SPIF_SENDCHANGE = 0x02
        
        # Primero: Establecer el nombre del esquema
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, 
                            r"Control Panel\Cursors", 
                            0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "Scheme Name", 0, winreg.REG_SZ, safe_scheme_name)
        
        # Segundo: Aplicar los cursores
        ctypes.windll.user32.SystemParametersInfoW(
            SPI_SETCURSORS,
            0,
            None,
            SPIF_UPDATEINIFILE | SPIF_SENDCHANGE
        )
        
        return True
    except Exception as e:
        messagebox.showerror("Error crítico", f"Error al configurar el registro:\n{e}\n\n{traceback.format_exc()}")
        return False

def load_image(img_path):
    """Carga una imagen para mostrar en la interfaz, con soporte para múltiples formatos"""
    try:
        # Intentar cargar la imagen
        image = Image.open(img_path).convert("RGBA")
        image = image.resize((64, 64), Image.LANCZOS)
        return ImageTk.PhotoImage(image)
    
    except Exception as e:
        print(f"Error al cargar {img_path}: {e}")
        # Crear placeholder de error si no existe
        if _PLACEHOLDER_CACHE['error'] is None:
            try:
                img = Image.new('RGBA', (64, 64), (255, 220, 220, 255))
                draw = ImageDraw.Draw(img)
                try:
                    font = ImageFont.truetype("arial.ttf", 10)
                except:
                    font = ImageFont.load_default()
                
                text = "Error"
                bbox = draw.textbbox((0, 0), text, font=font)
                text_width = bbox[2] - bbox[0]
                text_height = bbox[3] - bbox[1]
                position = ((64 - text_width) // 2, (64 - text_height) // 2)
                draw.text(position, text, fill="red", font=font)
                
                # Dibujar borde
                draw.rectangle([(0, 0), (63, 63)], outline="#FF8888", width=1)
                
                _PLACEHOLDER_CACHE['error'] = ImageTk.PhotoImage(img)
            except Exception as e2:
                print(f"Error creando placeholder: {e2}")
                return None
        return _PLACEHOLDER_CACHE['error']

def find_preview_image(folder_path):
    """Busca una imagen de vista previa en la carpeta (PNG, JPG, GIF)"""
    preview_extensions = ['.png', '.jpg', '.jpeg', '.gif']
    for file in os.listdir(folder_path):
        if any(file.lower().endswith(ext) for ext in preview_extensions):
            return os.path.join(folder_path, file)
    return None

def find_cursor_sets(cursor_dir):
    """Busca sets de cursores organizados por carpetas y subcarpetas"""
    cursor_categories = {}
    
    if not os.path.exists(cursor_dir):
        return cursor_categories

    # Recorrer recursivamente todas las carpetas
    for root, dirs, files in os.walk(cursor_dir):
        # Ignorar directorios ocultos
        if any(part.startswith('.') for part in root.split(os.sep)):
            continue
            
        # Buscar archivos INF
        for file in files:
            if file.lower() == "scheme.inf":
                inf_path = os.path.join(root, file)
                try:
                    scheme_name, cursor_map = parse_inf(inf_path)
                    
                    # Buscar una imagen de vista previa
                    preview_path = find_preview_image(root)
                    
                    # Obtener ruta relativa para categorización
                    rel_path = os.path.relpath(root, cursor_dir)
                    category = rel_path.split(os.sep)[0] if os.sep in rel_path else "General"
                    
                    if category not in cursor_categories:
                        cursor_categories[category] = []
                        
                    cursor_categories[category].append({
                        'name': scheme_name,
                        'path': root,
                        'cursor_map': cursor_map,
                        'preview_path': preview_path,
                        'rel_path': rel_path
                    })
                except Exception as e:
                    print(f"Error procesando {inf_path}: {e}")
    
    return cursor_categories

def create_no_preview_placeholder():
    """Crea un placeholder para cuando no hay vista previa disponible"""
    if _PLACEHOLDER_CACHE['no_preview'] is None:
        img = Image.new('RGBA', (64, 64), (240, 240, 240, 255))
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype("arial.ttf", 10)
        except:
            font = ImageFont.load_default()
        
        text = "Sin vista previa"
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        position = ((64 - text_width) // 2, (64 - text_height) // 2)
        draw.text(position, text, fill="#666666", font=font)
        
        # Dibujar borde punteado
        draw.rectangle([(0, 0), (63, 63)], outline="#CCCCCC", width=1, dash=(4, 2))
        
        _PLACEHOLDER_CACHE['no_preview'] = ImageTk.PhotoImage(img)
    return _PLACEHOLDER_CACHE['no_preview']

# Función para abrir la herramienta de cursores de Windows
def open_windows_cursor_tool():
    try:
        # Abrir directamente la pestaña de cursores
        subprocess.Popen(['control', 'main.cpl,,1'])
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo abrir la herramienta de cursores:\n{e}")

class CursorSelectorApp:
    def __init__(self, root):
        self.root = root
        self.cursor_dir = get_cursor_dir()
        self.update_button = None
        self.update_available = False
        
        # Crear objeto de estilos para los botones
        self.style = ttk.Style()
        self.style.configure("Update.TButton", foreground="black")
        
        # Variables de actualización
        self.current_version = self.get_current_version()
        
        # Crear carpeta de configuración si no existe
        os.makedirs(CONFIG_DIR, exist_ok=True)
        
        # Configurar interfaz
        self.setup_ui()
        
        # Verificar actualizaciones en segundo plano
        self.check_for_updates_in_background()
        
        # Mostrar cambios si es una nueva instalación
        self.show_update_changes_if_needed()

    def get_current_version(self):
        """Obtiene la versión actual de la aplicación"""
        try:
            if os.path.exists(VERSION_FILE):
                with open(VERSION_FILE, "r") as f:
                    return f.read().strip()
        except:
            pass
        return "1.0.5"  # Versión inicial

    def save_current_version(self, version):
        """Guarda la versión actual en un archivo"""
        try:
            with open(VERSION_FILE, "w") as f:
                f.write(version)
        except:
            pass

    def check_for_updates_in_background(self):
        """Verifica actualizaciones en segundo plano"""
        threading.Thread(target=self.check_updates, daemon=True).start()

    def check_updates(self, show_message=False):
        """Verifica si hay actualizaciones disponibles en GitHub"""
        try:
            current_version = self.get_current_version()
            response = urllib.request.urlopen(GITHUB_REPO, timeout=5)
            remote_version = response.read().decode().strip()
            
            if remote_version != current_version:
                self.update_available = True
                if show_message:
                    self.show_update_prompt(remote_version, current_version)
                self.root.after(0, self.update_ui_for_updates)
            else:
                self.update_available = False
                if show_message:
                    messagebox.showinfo("Actualización", "Ya tienes la última versión.")
                self.root.after(0, self.update_ui_for_updates)
        except Exception as e:
            self.update_available = False
            if show_message:
                messagebox.showerror("Error", f"No se pudo verificar actualizaciones: {str(e)}")
            self.root.after(0, self.update_ui_for_updates)

    def update_ui_for_updates(self):
        """Actualiza la UI para mostrar/ocultar el botón de actualización usando estilos"""
        if self.update_button:
            if self.update_available:
                # Cambiar a estilo de actualización disponible (texto rojo)
                self.style.configure("Update.TButton", foreground="red")
                self.update_button.config(
                    text="Actualización disponible!", 
                    style="Update.TButton"
                )
            else:
                # Volver al estilo normal (texto negro)
                self.style.configure("Update.TButton", foreground="black")
                self.update_button.config(
                    text="Buscar actualizaciones", 
                    style="Update.TButton"
                )

    def download_changelog(self):
        """Descarga el changelog desde GitHub"""
        try:
            with urllib.request.urlopen(GITHUB_CHANGELOG, timeout=5) as response:
                return response.read().decode('utf-8')
        except Exception as e:
            print(f"Error al descargar changelog: {e}")
            return "No se pudieron obtener las notas de la versión."

    def show_update_prompt(self, remote_version, current_version):
        """Muestra un diálogo informando sobre la nueva versión"""
        changelog = self.download_changelog()
        message = f"¡Hay una nueva versión disponible!\n\n" \
                  f"Versión actual: {current_version}\n" \
                  f"Nueva versión: {remote_version}\n\n" \
                  f"Notas de la versión:\n{changelog}\n\n" \
                  "¿Deseas actualizar ahora?"
        
        if messagebox.askyesno("Actualización disponible", message):
            self.perform_update(remote_version)

    def perform_update(self, remote_version):
        """Realiza el proceso de actualización"""
        try:
            changelog = self.download_changelog()
            with open(CHANGELOG_FILE, "w", encoding="utf-8") as f:
                f.write(remote_version + "\n\n" + changelog)
        except:
            pass
        
        if sys.platform == "win32":
            try:
                temp_dir = tempfile.gettempdir()
                installer_path = os.path.join(temp_dir, "Custom_Cursor_Updater.exe")
                
                with urllib.request.urlopen(INSTALLER_URL) as response:
                    with open(installer_path, 'wb') as out_file:
                        out_file.write(response.read())
                
                subprocess.Popen([installer_path, "/SILENT"])
                self.quit_app()
            except Exception as e:
                messagebox.showerror("Error de actualización", 
                                    f"No se pudo descargar el actualizador: {str(e)}\n"
                                    "Por favor, actualiza manualmente desde GitHub.")
                webbrowser.open(UPDATE_URL)
        else:
            webbrowser.open(UPDATE_URL)
            messagebox.showinfo("Actualización manual", "Por favor, descarga la última versión desde el navegador.")

    def show_update_changes_if_needed(self):
        """Muestra los cambios si se acaba de actualizar"""
        if os.path.exists(CHANGELOG_FILE):
            try:
                with open(CHANGELOG_FILE, "r", encoding="utf-8") as f:
                    content = f.read()
                    parts = content.split("\n\n", 1)
                    version = parts[0]
                    changelog = parts[1] if len(parts) > 1 else "No hay notas disponibles."
                
                messagebox.showinfo(f"Notas de la versión {version}", changelog)
                os.remove(CHANGELOG_FILE)
            except Exception as e:
                print(f"Error al mostrar cambios de actualización: {e}")

    def check_updates_ui(self):
        """Verifica actualizaciones desde la interfaz de usuario"""
        self.check_updates(show_message=True)
        
    def quit_app(self):
        """Cierra la aplicación"""
        self.root.destroy()

    def setup_ui(self):
        """Crea la interfaz de usuario principal"""
        try:
            self.root.title("Selector de Cursores")
            # Establecer tamaño fijo y deshabilitar redimensionamiento
            self.root.geometry("900x600")
            self.root.resizable(False, False)  # Deshabilitar redimensionamiento en ambos ejes
            
            # Establecer icono
            icon_path = get_icon_path()
            if icon_path:
                try:
                    self.root.iconbitmap(icon_path)
                except Exception as e:
                    print(f"Error al cargar el icono: {e}")
            
            # Cargar estructura de cursores
            cursor_sets = find_cursor_sets(self.cursor_dir)
            
            if not cursor_sets:
                # Mostrar mensaje de error y salir
                error_frame = ttk.Frame(self.root, padding=20)
                error_frame.pack(fill="both", expand=True)
                
                ttk.Label(
                    error_frame, 
                    text="⚠️ No se encontraron sets de cursores", 
                    font=("Segoe UI", 14, "bold"),
                    foreground="red"
                ).pack(pady=10)
                
                ttk.Label(
                    error_frame, 
                    text=f"Por favor, coloca tus sets de cursores en:\n{self.cursor_dir}",
                    justify="center"
                ).pack(pady=5)
                
                ttk.Label(
                    error_frame, 
                    text="Cada set debe tener un archivo scheme.inf y los archivos de cursor correspondientes",
                    wraplength=500,
                    justify="center"
                ).pack(pady=10)
                
                # Botón para salir
                ttk.Button(
                    error_frame, 
                    text="Salir", 
                    command=self.root.destroy
                ).pack(pady=5)
                
                return
            
            # Crear paneles principales
            main_panel = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
            main_panel.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
            # Panel izquierdo (lista de categorías)
            left_frame = ttk.Frame(main_panel, width=200)
            main_panel.add(left_frame, weight=1)
            
            # Panel derecho (vista previa y controles)
            right_frame = ttk.Frame(main_panel)
            main_panel.add(right_frame, weight=3)
            
            # Crear lista de categorías
            categories_frame = ttk.LabelFrame(left_frame, text="Categorías", padding=10)
            categories_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
            
            # Listbox con scroll para categorías
            scrollbar = ttk.Scrollbar(categories_frame)
            scrollbar.pack(side="right", fill="y")
            
            categories_list = tk.Listbox(
                categories_frame, 
                yscrollcommand=scrollbar.set,
                font=("Segoe UI", 10),
                selectmode="single"
            )
            categories_list.pack(fill="both", expand=True)
            scrollbar.config(command=categories_list.yview)
            
            # Llenar categorías
            all_categories = ["Todos"] + sorted(cursor_sets.keys())
            for category in all_categories:
                categories_list.insert("end", category)
            categories_list.select_set(0)  # Seleccionar "Todos" por defecto
            
            # Crear vista previa en el panel derecho
            preview_frame = ttk.LabelFrame(right_frame, text="Vista Previa", padding=10)
            preview_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
            
            # Canvas para los cursores
            canvas = tk.Canvas(preview_frame)
            scrollbar = ttk.Scrollbar(preview_frame, orient="vertical", command=canvas.yview)
            scrollable_frame = ttk.Frame(canvas)
            
            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )
            
            canvas.create_window((0, 0), window=scrollable_frame, anchor='nw')
            canvas.configure(yscrollcommand=scrollbar.set)
            
            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
            
            # Variables para mantener el estado
            current_selection = None
            self.cursor_widgets = []
            
            # Función para mostrar cursores por categoría
            def show_cursors(category):
                # Limpiar frame
                for widget in self.cursor_widgets:
                    widget.destroy()
                self.cursor_widgets.clear()
                
                # Obtener cursores para la categoría seleccionada
                if category == "Todos":
                    cursors = []
                    for cat_cursors in cursor_sets.values():
                        cursors.extend(cat_cursors)
                else:
                    cursors = cursor_sets.get(category, [])
                
                if not cursors:
                    no_cursors = ttk.Label(
                        scrollable_frame, 
                        text="No se encontraron cursores en esta categoría",
                        font=("Segoe UI", 10, "italic")
                    )
                    no_cursors.grid(row=0, column=0, padx=10, pady=10)
                    self.cursor_widgets.append(no_cursors)
                    return
                
                # Mostrar cursores en una grilla
                row, col = 0, 0
                max_cols = 3
                
                for cursor_info in cursors:
                    frame = ttk.Frame(scrollable_frame, borderwidth=1, relief="solid", padding=10)
                    frame.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
                    self.cursor_widgets.append(frame)
                    
                    # Vista previa de imagen
                    if cursor_info['preview_path']:
                        img = load_image(cursor_info['preview_path'])
                        if img:
                            img_label = ttk.Label(frame, image=img)
                            img_label.image = img  # Mantener referencia
                            img_label.pack(pady=5)
                            self.cursor_widgets.append(img_label)
                    else:
                        placeholder = create_no_preview_placeholder()
                        img_label = ttk.Label(frame, image=placeholder)
                        img_label.image = placeholder
                        img_label.pack(pady=5)
                        self.cursor_widgets.append(img_label)
                    
                    # Nombre del esquema
                    name_label = ttk.Label(
                        frame, 
                        text=cursor_info['name'],
                        font=("Segoe UI", 9, "bold"),
                        wraplength=150
                    )
                    name_label.pack(pady=3)
                    self.cursor_widgets.append(name_label)
                    
                    # Ruta relativa
                    path_label = ttk.Label(
                        frame, 
                        text=cursor_info['rel_path'],
                        font=("Segoe UI", 8),
                        foreground="gray",
                        wraplength=150
                    )
                    path_label.pack(pady=2)
                    self.cursor_widgets.append(path_label)
                    
                    # Botón para aplicar
                    def apply_action(info=cursor_info):
                        if set_cursor_registry(
                            info['cursor_map'], 
                            info['path'], 
                            info['name']
                        ):
                            messagebox.showinfo("✅ Éxito", f"Cursor '{info['name']}' aplicado correctamente")
                            # Abrir la herramienta de cursores de Windows automáticamente
                            open_windows_cursor_tool()
                        else:
                            messagebox.showerror("Error", "No se pudo aplicar el cursor")
                    
                    apply_btn = ttk.Button(
                        frame, 
                        text="Aplicar",
                        width=10,
                        command=apply_action
                    )
                    apply_btn.pack(pady=10)
                    self.cursor_widgets.append(apply_btn)
                    
                    # Actualizar posición
                    col += 1
                    if col >= max_cols:
                        col = 0
                        row += 1
            
            # Mostrar todos los cursores inicialmente
            show_cursors("Todos")
            
            # Configurar evento de selección de categoría
            def on_category_select(event):
                selection = categories_list.curselection()
                if selection:
                    category = categories_list.get(selection[0])
                    show_cursors(category)
            
            categories_list.bind("<<ListboxSelect>>", on_category_select)
            
            bottom_frame = ttk.Frame(self.root)
            bottom_frame.pack(fill=tk.X, padx=10, pady=5)
            
            # Botón para abrir la herramienta de personalización de Windows
            ttk.Button(
                bottom_frame, 
                text="Herramienta de cursores de Windows", 
                command=open_windows_cursor_tool
            ).pack(side="left", padx=5)
            
            # Botón para verificar actualizaciones con estilo
            self.update_button = ttk.Button(
                bottom_frame, 
                text="Buscar actualizaciones",
                style="Update.TButton",
                command=self.check_updates_ui
            )
            self.update_button.pack(side="right", padx=5)
            
            ttk.Button(
                bottom_frame, 
                text="Salir", 
                command=self.quit_app
            ).pack(side="right", padx=5)
            
        except Exception as e:
            messagebox.showerror("Error de interfaz", f"Error al crear la interfaz:\n{str(e)}")

def is_admin():
    """Verifica si la aplicación se está ejecutando con privilegios de administrador"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if __name__ == "__main__":
    try:
        # Obtener carpeta de cursores relativa al ejecutable/script
        CURSOR_DIR = get_cursor_dir()
        
        if not is_admin():
            # Reejecutar con privilegios de administrador
            script = os.path.abspath(sys.argv[0])
            params = " ".join(sys.argv[1:])
            
            # Construir el comando correctamente
            command = f'"{sys.executable}" "{script}"'
            if params:
                command += f' {params}'
            
            try:
                # Usar ShellExecuteW para mostrar el prompt UAC
                ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{script}"', None, 1)
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo obtener permisos de administrador:\n{e}")
            sys.exit(0)
        else:
            # Crear ventana principal
            root = tk.Tk()
            
            # Iniciar la aplicación
            app = CursorSelectorApp(root)
            
            # ===== FORZAR LA VENTANA AL FRENTE =====
            # 1. Traer al frente inmediatamente
            root.lift()
            
            # 2. Forzar el enfoque (funciona en Windows)
            root.attributes('-topmost', True)
            root.update()
            root.attributes('-topmost', False)
            
            # 3. Enfocar la ventana (método alternativo)
            root.focus_force()
            
            # 4. Enfocar la ventana principal y sus hijos
            root.after(100, lambda: root.focus_force())
            root.after(100, lambda: root.tkraise())
            
            root.mainloop()
    except Exception as e:
        error_msg = f"Error inesperado:\n{str(e)}\n\nTraceback:\n{traceback.format_exc()}"
        messagebox.showerror("Error crítico", error_msg)